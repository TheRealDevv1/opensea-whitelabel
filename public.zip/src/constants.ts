export const ASSET_URL =
  "https://opensea.io/assets/0x1301566b3cb584e550a02d09562041ddc4989b91/28";

export enum EmbedTheme {
  Default = "true",
  Simple = "simple",
}

export const CHOSEN_THEME = EmbedTheme.Default;
