export const ASSET_URL =
  "https://app.nftrade.com/assets/bsc/0xa4f492f6ee02f1c9f6751967c923fdb016dcd273/1";

export enum EmbedTheme {
  Default = "true",
  Simple = "simple",
}

export const CHOSEN_THEME = EmbedTheme.Default;
